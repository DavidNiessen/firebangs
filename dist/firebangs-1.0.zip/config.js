export default {
  fetchRemoteData: false,
  remoteDataUrl: 'https://duckduckgo.com/bang.js'
}