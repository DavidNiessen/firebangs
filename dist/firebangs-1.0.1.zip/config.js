export default {
  remoteDataUrl: 'https://raw.githubusercontent.com/DavidNiessen/firebangs/refs/heads/main/assets/bangs.json',
  updateAfterMs: 3_600_000
}